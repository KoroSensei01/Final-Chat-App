you will need to install dependecies at client, server and socket folders by running npm install at each, 
then you will have to connect to your mongodb atlas by adding the connection string with the correct password at the .env file at the server, 
also add a jwtkey on the same file. then run npm run dev on client and nodemon on server and socket to run them.


dependenicies are usually at the package.json file. 

All you need to do is open the client folder at the terminal  and then run npm install
they will be picked automatically from package.json file
then you will do the same for server and socket folder



you can put your mongodb link on .env and put a jwtkey

to run the database on server and socket just type npx nodemon
and for the local host on client just type npm run dev